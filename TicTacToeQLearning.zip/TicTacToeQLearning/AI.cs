﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TicTacToeQLearning
{
    class AI
    {
        static double highest = 0;
        static double lowest = 1;
        public static double EPSILON = 1;
        public static double GAMMA = 0.5;
        public static double ALPHA = 0.2;

        public static double stepPrice = 0;
        public static double[][] Q;
        int team;
        Field field;
        public AI(Field field, int team)
        {
            this.team = team;
            this.field = field;

            Q = new double[Field.states.Count][];
            for (int a = 0; a < Field.states.Count; a++)
            {
                Q[a] = new double[9];
            }
            ResetQ();
        }
        public void FillQ(StreamReader sr)
        {
            int c = 0;
            for(int a = 0; a < Field.states.Count; a++)
            {
                for(int b = 0; b < 9; b++)
                {
                    c++;
                    string v = sr.ReadLine();
                    double val = double.Parse(v);
                    Q[a][b] = val;
                }
            }
        }
        public bool MakeCertainMove(int action)
        {
            State currentState = field.GetCurrentState(team);

            if (currentState.Aim != 0)
                throw new Exception("MakeCertainMove: current State is Final:\n" + currentState.getContent(0));

            int currentIndex = currentState.getIndex();
            if (currentState.nextState[0][action] == null)
            {
                Console.WriteLine("Not possible: " + currentState.Aim);
                return false;
            }
            Console.WriteLine(Field.Printable(currentState.getContent(0)));
            field.SetPosition(action, team, false);
            State enemyState = field.GetCurrentState(team % 2 + 1);
            int enemyStateIndex = enemyState.getIndex();
            double reward = field.getReward();
            if (enemyState.Aim == 2 || currentState.Aim == 2)
            {
                reward = 40;
            }

            double q = Q[currentIndex][action];
            double newQ = 0;
            if (reward != 0)
            {
                newQ = reward - q;
            }
            else
            {

                double qualityNextState = HighestValue(Q[enemyStateIndex]) - stepPrice;
                if (enemyState.Aim == 1)
                {
                    qualityNextState = 100;
                }
                newQ = (reward + GAMMA * (100 - qualityNextState)) - q;
            }

            Q[currentIndex][action] = q + ALPHA * newQ;

            if (q + ALPHA * newQ > highest)
                highest = q + ALPHA * newQ;
            else if (q + ALPHA * newQ < lowest)
                lowest = q + ALPHA * newQ;

            return true;
        }
        public bool MakeMove(bool rand, int start)
        {
            State currentState = field.GetCurrentState(team);

            if (currentState.Aim != 0)
                throw new Exception("MakeMove: current State is Final:\n" + currentState.getContent(0));

            int currentIndex = currentState.getIndex();

            int action = 0;

            if(rand)
            {
                List<int> possibleActions = new List<int>();
                for(int a = 0; a < 9; a++)
                {
                    if(currentState.getContent(0)[a] == '0')
                    {
                        possibleActions.Add(a);
                    }
                    
                }
                action = possibleActions[Program.random.Next(0, possibleActions.Count)];
            }
            else
            {
                action = HighestIndex(Q[currentIndex]);
            }
            field.SetPosition(action, team, false);
            State enemyState = field.GetCurrentState(team % 2 + 1);
            int enemyStateIndex = enemyState.getIndex();
            double reward = field.getReward();
            if(enemyState.Aim == 2 || currentState.Aim == 2)
            {
                reward = 40;
            }

            double q = Q[currentIndex][action];
            double newQ = 0;

            if (reward != 0)
            {
                newQ = reward - q;
            }
            else
            {

                double qualityNextState = HighestValue(Q[enemyStateIndex]) - stepPrice;
                if(enemyState.Aim == 1)
                {
                    qualityNextState = 100;
                }
                newQ = (reward + GAMMA * ( 100 - qualityNextState)) - q;
            }
            

            Q[currentIndex][action] = q + ALPHA * newQ;

            if (reward != 0 && EPSILON > 0)
            {
                EPSILON *= 1 - (1.0000 / 10000000);
                //Console.WriteLine(EPSILON);
                return false;
            }
            else if(reward != 0)
            {
                return false;
            }
                return true;
            //TODO
            /*
             * Q Array füllen
             * vorausschauendes Verhalten einfügen
             * 
             * */
        }
        void GoBack(string s, double highest)
        {
            int currentIndex = field.FindStateIndex(s);
            double highestValue = HighestValue(Q[currentIndex]);
            highestValue = highest > highestValue ? highest : highestValue;
            int C1 = Field.CharCount(s, '1');
            int C2 = Field.CharCount(s, '2');
            if (C1 == 0 && C2 == 0)
                return;
            else if (C1 > C2)
            {
                for (int a = 0; a < s.Length; a++)
                {
                    if (s[a] == '1')
                    {
                        string newString = "";
                        for (int b = 0; b < s.Length; b++)
                        {
                            if (b == a)
                            {
                                newString += 0;
                                continue;
                            }
                            newString += s[b];
                        }
                        int newIndex = field.FindStateIndex(newString);
                        if (Q[newIndex][a] == highestValue * GAMMA && Q[newIndex][a] != 0)
                        {
                            Q[newIndex][a] = 0;
                            GoBack(newString, highestValue);
                        }
                    }
                }
            }
            else if (C1 < C2)
            {
                for (int a = 0; a < s.Length; a++)
                {
                    if (s[a] == '2')
                    {
                        string newString = "";
                        for (int b = 0; b < s.Length; b++)
                        {
                            if (b == a)
                            {
                                newString += 0;
                                continue;
                            }
                            newString += s[b];
                        }
                        int newIndex = field.FindStateIndex(newString);
                        if (Q[newIndex][a] == highestValue * GAMMA && Q[newIndex][a] != 0)
                        {
                            Q[newIndex][a] = 0;
                            GoBack(newString, highestValue);
                        }
                    }
                }
            }
            else if (C1 == C2)
            {
                for (int a = 0; a < s.Length; a++)
                {
                    if (s[a] != '0')
                    {
                        string newString = "";
                        for (int b = 0; b < s.Length; b++)
                        {
                            if (b == a)
                            {
                                newString += 0;
                                continue;
                            }
                            newString += s[b];
                        }
                        int newIndex = field.FindStateIndex(newString);
                        if (Q[newIndex][a] == highestValue * GAMMA && Q[newIndex][a] != 0)
                        {
                            Q[newIndex][a] = 0;
                            GoBack(newString, highestValue);
                        }
                    }
                }
            }
        }
        public bool MakeMove(int start, StreamWriter sw)
        {
            State current = field.GetCurrentState(team);
            int index = current.getIndex();
            int action = HighestIndex(Q[index]);
            sw.Write("\t"+ team + " : " + action);
            sw.Flush();
            field.SetPosition(action, team, false);
            double reward = field.getReward();
            if (reward != 0)
            {
                if (reward == 100)
                {
                    sw.Write("\tWin\a");
                }
                else
                {
                    sw.Write("\tDraw\a");
                }
                return false;
            }
            else
                return true;
        }
        #region Utility

        int HighestIndex(double[] vals)
        {
            double highest = double.MinValue;
            int index = 0;
            for (int a = 0; a < vals.Length; a++)
            {
                if (vals[a] > highest)
                {
                    highest = vals[a];
                    index = a;
                }
            }
            return index;
        }
        double HighestValue(double[] vals)
        {
            double highest = double.MinValue;
            for (int a = 0; a < vals.Length; a++)
            {
                if (vals[a] > highest)
                {
                    highest = vals[a];
                }
            }
            return highest == -200 ? 0 : highest;
        }

        #endregion

        public static void ResetQ()
        {
            for (int a = 0; a < Field.states.Count; a++)
            {
                for (int b = 0; b < 9; b++)
                {
                    Q[a][b] = Field.states[a].nextState[0][b] == null ? -200 : 0;
                }
            }
        }
    }
}
