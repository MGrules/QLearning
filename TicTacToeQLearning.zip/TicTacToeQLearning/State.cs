﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToeQLearning
{
    class State
    {
        protected string content;
        protected int index;
        public State[][] nextState;
        public int Aim;

        public State(string c, int i)
        {
            Aim = 0;
            nextState = new State[2][];
            for(int a = 0; a < 2; a++)
            {
                nextState[a] = new State[9];
            }
            content = c;
            index = i;
        }

        public void setContent(string newContent)
        {
            content = newContent;
        }
        public string getContent(int view)
        {
            string result = "";
            if(view == 2)
            {
                for(int a = 0; a < content.Length; a++)
                {
                    char c = content[a];
                    if (c == '1')
                        c = '2';
                    else if (c == '2')
                        c = '1';

                    result += c;
                }
            }
            else
            {
                result = content;
            }
            return result;
        }

        public void setIndex(int newIndex)
        {
            index = newIndex;
        }
        public int getIndex()
        {
            return index;
        }
    }
}
