﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace TicTacToeQLearning
{
    
    class Field
    {
        public static List<State> states = new List<State>();
        public List<State> finishedStates = new List<State>();
        public State[] currentState;
        bool gotCombinations = false;

        double WinReward = 100;
        double DrawReward = 20;

        int[][] field;

        public Field()
        {
            currentState = new State[2];
            field = new int[3][];
            for(int a = 0; a < 3; a++)
            {
                field[a] = new int[3];
                for(int b = 0; b < 3; b++)
                {
                    field[a][b] = 0;
                }
            }
        }
        public void Reset()
        {
            for(int a = 0; a < 3; a++)
            {
                for(int b = 0; b < 3; b++)
                {
                    field[a][b] = 0;
                }
            }
            currentState[0] = states[0];
            currentState[1] = states[0];
        }
        public void setFirstState(int index)
        {
            State startState = states[index];
            State startState2 = FindState(startState.getContent(2));

            if(CharCount(startState.getContent(0), '1') <= CharCount(startState.getContent(0), '2'))
            {
                currentState[0] = startState;
                currentState[1] = startState2;
            }
            else
            {
                currentState[1] = startState;
                currentState[0] = startState2;
            }

        }
        public void SetRandomState(int start)
        {
            State startState = states[0];
            do
            {
                startState = states[Program.random.Next(0, states.Count)];
                if (startState.Aim == 0 && CharCount(startState.getContent(0), '1') == CharCount(startState.getContent(0), '2'))
                {
                    //Console.WriteLine(CharCount(startState.getContent(0), '1') + ":" + CharCount(startState.getContent(0), '2'));
                    break;
                }

            } while (true);

            /*Console.WriteLine(startState.getContent(1));
            Console.WriteLine(startState.getContent(2));
            */

            currentState[0] = FindState(startState.getContent(2));
            currentState[1] = startState;
            if (currentState[0] == null || currentState[1] == null)
                throw new Exception("No state found");
        }
        public double getReward()
        {
            if (currentState[0].Aim == 1)
                return WinReward;
            else if (currentState[0].Aim == 2)
                return DrawReward;
            else
                return 0;
        }
        public State GetCurrentState(int team)
        {
            return currentState[team - 1];
        }
        public string getCombination(int view)
        {
            
            if(currentState[0] == null)
            {
                string r = "";
                for(int a = 0; a < 3; a++)
                {
                    for(int b = 0; b < 3; b++)
                    {
                        r += field[a][b];
                    }
                }
                if (view == 2)
                {
                    r.Replace('1', '3');
                    r.Replace('2', '1');
                    r.Replace('3', '2');
                }
                return r;
            }
            return currentState[0].getContent(view);
        }
        public void SetPosition(int position, int value, bool ignoreNotZero)
        {
            if(field[position / 3][position % 3] == 0 || ignoreNotZero)
            {
                field[position / 3][position % 3] = value;
            }
            if (ignoreNotZero)
                return;

            State lastState1 = currentState[0];
            State lastState2 = currentState[1];
            currentState[0] = lastState1.nextState[value - 1][position];
            currentState[1] = lastState2.nextState[value % 2][position];

            if (currentState[0] == null || currentState[1] == null)
                throw new Exception("No state found");
        }
        
#region GetCombinations
        List<string> combinations = new List<string>();
        public void GetCombinations(string file, bool print)
        {
            if (gotCombinations)
                return;

            gotCombinations = true;
            if (file.Contains(":/"))
            {
                FileStream f = new FileStream(file, FileMode.Open);
                StreamReader sr = new StreamReader(f);//ermöglicht das Lesen aus einem Input-Stream wie dem FileStream

                string s = sr.ReadLine();
                while (s != null)
                {
                    if (print) Console.WriteLine("|" + s + "|");
                    this.combinations.Add(s);
                    s = sr.ReadLine();
                }
                goto ConvertStringToState;
            }
            //find every possible state, the field can be in
            Layer(0, print);
            //remove every combination, that cant be reached in a normal game (one player makes more than 1 move more than the other player

            List<string> remove = new List<string>();
            for (int a = 0; a < combinations.Count; a++)
            {
                int ones = CharCount(combinations[a], '1');
                int twos = CharCount(combinations[a], '2');
                if (Math.Abs(twos - ones) > 1)
                {
                    remove.Add(combinations[a]);
                }
            }
            for (int a = 0; a < remove.Count; a++)
            {
                combinations.Remove(remove[a]);
            }
            if (print)
            {

                for (int a = 0; a < combinations.Count; a++)
                {
                    Console.WriteLine(Printable(combinations[a])/*siehe "Print"*/);
                }
            }
            Console.WriteLine("Where do you want to save the data?");
            file = Console.ReadLine();
            FileStream fs = new FileStream(file, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            for (int a = 0; a < combinations.Count; a++)
            {
                sw.WriteLine(combinations[a]);
                sw.Flush();
            }
            ConvertStringToState:;
            for (int a = 0; a < combinations.Count; a++)
            {
                State s = new State(combinations[a], a);
                states.Add(s);
            }
            for (int a = 0; a < states.Count; a++)
            {
                string currentState = states[a].getContent(0);

                states[a].Aim = CheckAim(currentState);
                if(states[a].Aim != 0)
                {
                    finishedStates.Add(states[a]);
                }

                Console.WriteLine(Printable(currentState));
                for (int b = 0; b < 2; b++)
                {
                    for (int c = 0; c < 9; c++)
                    {
                        State temp = FindState(StateAfterAction(currentState, c, b + 1));

                        if (currentState[c] != '0') // wird ein benutztes Feld überschrieben, wird ein Zustand ausgewählt, der nicht möglich ist
                            temp = null;

                        states[a].nextState[b][c] = temp;
                        /*if (temp == null)
                        {
                            Console.Write("--\t");
                        }
                        else
                        {
                            Console.Write(temp.getContent(0)+ "\t");
                        }*/
                    }
                }
            }
            finishedStates.Sort(delegate (State a, State b) 
            { return a.Aim.CompareTo(b.Aim);
            }
            );
        }
        int CheckAim(string s)
        {

            if (s[0] != '0' && s[0] == s[1] && s[0] == s[2])
            {               //X|X|X
                return 1;   // | |
            }               // | |
            else if (s[3] != '0' && s[3] == s[4] && s[3] == s[5])
            {               // | | 
                return 1;   //X|X|X
            }               // | |
            else if (s[6] != '0' && s[6] == s[7] && s[6] == s[8])
            {               // | |
                return 1;   // | |
            }               //X|X|X
            else if (s[0] != '0' && s[0] == s[3] && s[0] == s[6])
            {               //X| | 
                return 1;   //X| |
            }               //X| |
            else if (s[1] != '0' && s[1] == s[4] && s[1] == s[7])
            {               // |X| 
                return 1;   // |X|
            }               // |X|
            else if (s[2] != '0' && s[2] == s[5] && s[2] == s[8])
            {               // | |X
                return 1;   // | |X
            }               // | |X
            else if (s[0] != '0' && s[0] == s[4] && s[0] == s[8])
            {               //X| |
                return 1;   // |X|
            }               // | |X
            else if (s[2] != '0' && s[2] == s[4] && s[2] == s[6])
            {               // | |X
                return 1;   // |X|
            }               //X| |
            else if(CharCount(s, '0') == 0)
            {
                return 2;
            }
            return 0;
        }
        string StateAfterAction(string s, int action, int value)
        {
            string r = "";
            for(int a = 0; a < s.Length; a++)
            {
                if( a == action)
                {
                    r += value;
                    continue;
                }
                r += s[a];
            }
            return r;
        }
        public State StateAfterAction(int action, int team)
        {
            State current = GetCurrentState(team);
            return current.nextState[1][action];
        }
        void Layer(int layer, bool print)
        {
            if (layer == 9)
            {
                string s = getCombination(0);
                combinations.Add(s);
                if (print) Console.WriteLine(s);
                return;
            }
            for (int a = 0; a < 3; a++)
            {
                SetPosition(layer, a, true);
                Layer(layer + 1, print);
            }

        }

        public static int CharCount(string s, char c)
        {
            int count = 0;
            for (int a = 0; a < s.Length; a++)
            {
                if (s[a] == c)
                    count++;
            }
            return count;
        }

        public State FindState(string s)
        {
            for (int a = 0; a < states.Count; a++)
            {
                if (states[a].getContent(0) == s)
                    return states[a];
            }
            
            return null;
        }
        public int FindStateIndex(string s)
        {
            for (int a = 0; a < combinations.Count; a++)
            {
                if (combinations[a] == s)
                    return a;
            }
            return -1;
        }
        //------------------------------End Get Combinations-------------------------------------
        public static string Printable(string s)
        {
            string r = "";
            for (int a = 0; a < s.Length; a++)
            {
                if (a % 3 == 0)
                {
                    r += "\n";
                }
                r += s[a] + "|";
            }
            return r;
        }
#endregion

    }
}
