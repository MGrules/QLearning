﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace TicTacToeQLearning
{
    class Program
    {
        static FileStream QStream;
        
        static FileStream fs;
        public static Random random = new Random();
        static Field field = new Field();
        static string file;
        static bool gotCombinations = false;
        static AI[] players;
        static bool playersInitiated = false;

        static StreamWriter ActionLog;

        public static void Main(string[] args)
        {
            Console.WriteLine("Enter best Action Log");
            string f = Console.ReadLine();

            ActionLog = new StreamWriter(new FileStream(f, FileMode.OpenOrCreate));
            while (true)
            {
                Console.WriteLine("0: Get Combinations\n1: Train\n2: Print Sequence\n3: Print Q\n4: Save Q\n5: Exit\n6: Assign Values");
                int input = int.Parse(Console.ReadLine());
                switch (input)
                {
                    case (0):
                        if (gotCombinations)
                            break;
                        gotCombinations = true;
                        Console.WriteLine("Where are the combinations?");
                        string file = Console.ReadLine();
                        if (file == "__")
                            file = "D:/TicTacToeFile.txt";

                        field.GetCombinations(file, true);
                        break;
                    case (1):
                        if (!gotCombinations)
                        {
                            Console.WriteLine("Where are the combinations?");
                            file = Console.ReadLine();
                            if (file == "__")
                                file = "D:/TicTacToeFile.txt";

                            field.GetCombinations(file, false);
                            gotCombinations = true;
                        }
                        if (!playersInitiated)
                        {
                            players = new AI[2];
                            for (int a = 0; a < 2; a++)
                            {
                                players[a] = new AI(field, a + 1);
                            }
                            playersInitiated = true;
                            Console.WriteLine("Q-Data?[Y/N]");
                            string inS = Console.ReadLine();
                            if (inS == "N" || inS == "n")
                            {
                                Console.WriteLine("Where?");
                                string path = Console.ReadLine();
                                if (path == "__")
                                    path = "D:/QData.txt";
                                QStream = new FileStream(path, FileMode.Create);

                                //ConfigureLastActions();
                            }
                            else
                            {
                                Console.WriteLine("Where?");
                                string path = Console.ReadLine();
                                if (path == "__")
                                    path = "D:/QData.txt";

                                QStream = new FileStream(path, FileMode.Open);
                                
                                for(int a = 0; a < 2; a++)
                                {
                                    QStream.Seek(0, SeekOrigin.Begin);
                                    players[a].FillQ(new StreamReader(QStream));
                                }
                            }
                            
                        }
                        Console.WriteLine("Use EPSILON-GREEDY EXPLOITATION? [Y/N]");
                        string s = Console.ReadLine();
                        if (s == "N" || s == "n")
                        {
                            AI.EPSILON = 0;
                        }
                        else if (AI.EPSILON == 0)
                        {
                            AI.EPSILON = 1;
                        }
                        Train();
                        break;
                    case (2):
                        PrintSolution();
                        break;
                    case (3):
                        PrintQ();
                        break;
                    case (4):
                        SaveQ();
                        break;
                    case (5):
                        return;
                    case (6):
                        AssignValues();
                        break;
                    case (7):
                        PlayManually();
                        break;
                    case (8):
                        AutomateLearnAndCapture();
                        break;

                }
            }
        }
        static void AssignValues()
        {
            double oldA = AI.ALPHA;
            double oldG = AI.GAMMA;
            double oldS = AI.stepPrice;
            Console.WriteLine("New Alpha?");
            AI.ALPHA = double.Parse(Console.ReadLine().Replace('.', ','));
            Console.WriteLine(AI.ALPHA);
            Console.WriteLine("New Gamma?");
            AI.GAMMA = double.Parse(Console.ReadLine().Replace('.',','));//(Console.ReadLine());
            Console.WriteLine(AI.GAMMA);
            Console.WriteLine("New Step Prize?");
            AI.stepPrice = double.Parse(Console.ReadLine().Replace('.', ','));
            Console.WriteLine(AI.stepPrice);
            if (!playersInitiated)
                return;

            DoActionLog(oldA, oldG, oldS);


            AI.ResetQ();
        }
        static void DoActionLog(double oldA, double oldG, double oldS)
        {
            ActionLog.WriteLine("A:" + oldA + "  G:" + oldG + "  S:" + oldS);
            ActionLog.WriteLine();
            ActionLog.Flush();
            field.Reset();
            int start = random.Next(0, 2);
            int player = start;
            while (players[player].MakeMove(start, ActionLog))
            {
                player = player == 0 ? 1 : 0;
            }
            ActionLog.WriteLine();
            ActionLog.Flush();
            field.Reset();
            player = start;
            while (players[player].MakeMove(false, start))
            {
                player = player == 0 ? 1 : 0;
                ActionLog.WriteLine(field.getCombination(0));
                ActionLog.Flush();
            }

            ActionLog.WriteLine(field.getCombination(0));
            ActionLog.WriteLine();
            ActionLog.WriteLine();
            ActionLog.Flush();
        }
        static void AutomateLearnAndCapture()
        {
            if (!gotCombinations)
            {
                Console.WriteLine("Where are the combinations?");
                file = Console.ReadLine();
                if (file == "__")
                    file = "D:/TicTacToeFile.txt";

                field.GetCombinations(file, false);
                gotCombinations = true;
            }
            if (!playersInitiated)
            {
                players = new AI[2];
                for (int a = 0; a < 2; a++)
                {
                    players[a] = new AI(field, a + 1);
                }
                playersInitiated = true;
            }

            for (double alpha = 0.1; alpha <= 0.9; alpha += 0.2)
            {
                
                for(double gamma = 0.1; gamma <= 0.9; gamma += 0.2)
                {
                    for(int step = 0; step <= 10; step += 5)
                    {
                        AI.ALPHA = alpha;
                        AI.GAMMA = gamma;
                        AI.stepPrice = step;
                        AI.ResetQ();
                        Train(new StreamWriter(new FileStream("D:/TTTData/" + alpha * 100 + "-" + gamma * 10 + "-" + step + ".txt", FileMode.Create)));
                        DoActionLog(alpha, gamma, step);

                    }
                }
                
            }
        }
        static void Train(StreamWriter sw)
        {
            if (fs == null)
            {
                Console.WriteLine("Where do you want to save the log?");
                string s = Console.ReadLine();
                if (s == "__")
                    s = "D:/TTTLog.txt";

                fs = new FileStream(s, FileMode.Create);

            }
            StreamWriter writer = new StreamWriter(fs);
            for (int q = 0; q < 40; q++)
            {
                for (int p = 0; p < Field.states.Count; p++)
                {
                    writer.WriteLine("Run: " + q + ":" + p);
                    Console.WriteLine("__________________________________________\n" +
                                      "__________________________________________\n" +
                                      "Run: " + q + ":" + p);
                    for (int a = 0; a < 9; a++)
                    {
                        //Game();
                        Game(p, a);
                    }
                    Console.WriteLine("--------------------------------");
                    field.Reset();
                    int start = random.Next(0, 2);
                    int player = start;
                    while (players[player].MakeMove(start, writer))
                    {
                        player = player == 0 ? 1 : 0;
                    }
                    writer.WriteLine();
                    writer.Flush();
                    field.Reset();
                    player = start;
                    while (players[player].MakeMove(false, start))
                    {
                        player = player == 0 ? 1 : 0;
                        writer.WriteLine(field.getCombination(0));
                        writer.Flush();
                    }

                    writer.WriteLine(field.getCombination(0));
                    writer.WriteLine();
                    writer.WriteLine();
                    writer.Flush();
                    field.Reset();
                    player = start;
                    while (players[player].MakeMove(false, start))
                    {
                        player = player == 0 ? 1 : 0;
                    }
                    if(field.currentState[0].Aim == 1)
                    {
                        sw.WriteLine("1");
                    }
                    else
                    {
                        sw.WriteLine("0");
                    }
                    sw.Flush();
                }
            }
        }
        static void Train()
        {
            
            
            if (fs == null)
            {
                Console.WriteLine("Where do you want to save the log?");
                string s = Console.ReadLine();
                if (s == "__")
                    s = "D:/TTTLog.txt";

                fs = new FileStream(s, FileMode.Create);
                
            }
            StreamWriter writer = new StreamWriter(fs);
            for (int q = 0; q < 40; q++)
            {
                for (int p = 0; p < Field.states.Count; p++)
                {
                    writer.WriteLine("Run: " + q + ":"+ p);
                    Console.WriteLine("__________________________________________\n" +
                                      "__________________________________________\n" + 
                                      "Run: " + q + ":" + p);
                    for(int a = 0; a < 9; a++)
                    {
                        //Game();
                        Game(p,a);
                    }
                    Console.WriteLine("--------------------------------");
                    field.Reset();
                    int start = random.Next(0, 2);
                    int player = start;
                    while (players[player].MakeMove(start, writer))
                    {
                        player = player == 0 ? 1 : 0;
                    }
                    writer.WriteLine();
                    writer.Flush();
                    field.Reset();
                    player = start;
                    while (players[player].MakeMove(false, start))
                    {
                        player = player == 0 ? 1 : 0;
                        writer.WriteLine(field.getCombination(0));
                        writer.Flush();
                    }

                    writer.WriteLine(field.getCombination(0));
                    writer.WriteLine();
                    writer.WriteLine();
                    writer.Flush();
                }
            }
        }
        static void Game()
        {
            field.Reset();
            int start = random.Next(0,2);
            int p = start;

            Console.WriteLine();
            Console.WriteLine("Player " + (p + 1));
            while (players[p].MakeMove(true, start))
            {
                p = p == 0 ? 1 : 0;
                Console.WriteLine("Player " + (p + 1));
                Console.WriteLine(Field.Printable(field.getCombination(0)));
                //Console.ReadLine();
            }
        }
        static void Game(int g, int action)
        {
            Console.WriteLine(Field.states[g].getContent(0) + "\t" + action);
            field.Reset();
            field.setFirstState(g);
            if (field.currentState[0].Aim != 0)
            {
                return;
            }
            int start = Field.CharCount(field.getCombination(0), '1') >= Field.CharCount(field.getCombination(0), '2') ? 1 : 0;
            int p = start;
            Console.WriteLine();
            Console.WriteLine("First Player " + (p + 1));
            if (!players[p].MakeCertainMove(action))
            {
                Console.WriteLine("Returning");
                return;
            }
            if (field.currentState[0].Aim != 0)
            {
                return;
            }
            p = p == 0 ? 1 : 0;
            
            Console.WriteLine();
            Console.WriteLine("Player " + (p + 1));
            while (players[p].MakeMove(true, start))
            {
                p = p == 0 ? 1 : 0;
                Console.WriteLine("Player " + (p + 1));
                Console.WriteLine(Field.Printable(field.getCombination(0)));
                //Console.ReadLine();
            }
            //Console.WriteLine(Field.Printable(field.getCombination(0)) + "\n--------------------------------");
        }

        static void PrintSolution()
        {
            field.Reset();
            int start = random.Next(0, 2);
            int p = start;
            while (players[p].MakeMove(false, start))
            {
                p = p == 0 ? 1 : 0;
                Console.WriteLine(Field.Printable(field.getCombination(0)));
                for (int a = 0; a < 9; a++)
                {
                    Console.WriteLine(AI.Q[field.GetCurrentState(p + 1).getIndex()][a]);
                }
            }
            Console.WriteLine(Field.Printable(field.getCombination(0)) + "\n--------------------------------");
        }
        static void PlayManually()
        {
            field.Reset();
            int team = 1;
            while(field.getReward() == 0)
            {
                Console.WriteLine(Field.Printable(field.getCombination(0)));
                int action = int.Parse(Console.ReadLine());
                field.SetPosition(action, team, false);
                /*Console.WriteLine(field.currentState[0].getContent(0));
                Console.WriteLine("---------------------------------------------------------------");
                Console.WriteLine(field.currentState[1].getContent(0));
                */
                for(int a = 0; a < 9; a++)
                {
                    Console.WriteLine(AI.Q[field.currentState[0].getIndex()][a]);
                }
                team = team % 2;
                team++;
            }
        }
        static void PrintQ()
        {
            for(int index = 0; index < AI.Q.Length; index++)
            {
                Console.WriteLine(Field.Printable(Field.states[index].getContent(0)));
                for(int action = 0; action < 9; action++)
                {
                    string v1 = "" + AI.Q[index][action];
                    if (v1 == "-200")
                        v1 = "-";

                    Console.Write(v1 +"\t");
                }
                Console.WriteLine();
            }
        }
        static void ConfigureLastActions()
        {
            for(int a = 0; a < field.finishedStates.Count; a++)
            {
                State firstState = field.finishedStates[a];
                field.setFirstState(firstState.getIndex());
                
                for (int p = 0; p < 9; p++)
                {
                    string s = "";
                    string n = firstState.getContent(0);
                    for(int x = 0; x < n.Length; x++)
                    {
                        if( x == p)
                        {
                            s += "0";
                            continue;
                        }
                        s += n[x];
                    }
                    State state = field.FindState(s);
                    if (state == null||state.Aim != 0)
                        continue;
                    string content = state.getContent(0);
                    field.setFirstState(state.getIndex());
                    if(Field.CharCount(content, '1') > Field.CharCount(content, '2'))
                    {
                        int player = 1;
                        for(int action = 0; action < 9; action++)
                        {
                            players[player].MakeCertainMove(action);
                            field.setFirstState(state.getIndex());
                        }
                    }
                    else if (Field.CharCount(content, '1') < Field.CharCount(content, '2'))
                    {
                        int player = 0;
                        for (int action = 0; action < 9; action++)
                        {
                            players[player].MakeCertainMove(action);
                            field.setFirstState(state.getIndex());
                        }
                    }
                    else
                    {

                        for (int player = 0; player < 2; player++)
                        {
                            for (int action = 0; action < 9; action++)
                            {
                                players[player].MakeCertainMove(action);
                                field.setFirstState(state.getIndex());
                            }
                        }
                    }

                    for (int q = 0; q < 9; q++)
                    {
                        string t = "";
                        for (int x = 0; x < n.Length; x++)
                        {
                            if (x == p)
                            {
                                t += "0";
                                continue;
                            }
                            t += s[x];
                            State state2 = field.FindState(s);
                            if (state2 == null||state2.Aim != 0)
                                continue;
                            string content2 = state2.getContent(0);
                            field.setFirstState(state2.getIndex());
                            if (Field.CharCount(content2, '1') > Field.CharCount(content2, '2'))
                            {
                                int player = 1;
                                for (int action = 0; action < 9; action++)
                                {
                                    players[player].MakeCertainMove(action);
                                    field.setFirstState(state2.getIndex());
                                }
                            }
                            else if (Field.CharCount(content2, '1') < Field.CharCount(content2, '2'))
                            {
                                int player = 0;
                                for (int action = 0; action < 9; action++)
                                {
                                    players[player].MakeCertainMove(action);
                                    field.setFirstState(state2.getIndex());
                                }
                            }
                            else
                            {

                                for (int player = 0; player < 2; player++)
                                {
                                    for (int action = 0; action < 9; action++)
                                    {
                                        players[player].MakeCertainMove(action);
                                        field.setFirstState(state2.getIndex());
                                    }
                                }
                            }
                            
                        }
                    }
                    Console.WriteLine(a + ": " + p );
                }
            }
            StreamWriter sw = new StreamWriter(QStream);
            for(int a = 0; a < Field.states.Count; a++)
            {
                for(int b = 0; b < 9; b++)
                {
                    sw.WriteLine(AI.Q[a][b]);
                    sw.Flush();
                }
            }
        }
        static void SaveQ()
        {
            if(QStream != null)
            {
                QStream.Close();
            }
            Console.WriteLine("Where?");
            string path = Console.ReadLine();
            if (path == "__")
                path = "D:/QData.txt";

            QStream = new FileStream(path, FileMode.Create);
            StreamWriter sw = new StreamWriter(QStream);

            for(int state = 0; state < Field.states.Count; state++)
            {
                for(int a = 0; a < 9; a++)
                {
                    sw.WriteLine(AI.Q[state][a]);
                    sw.Flush();
                }
            }
        }
    }
}
