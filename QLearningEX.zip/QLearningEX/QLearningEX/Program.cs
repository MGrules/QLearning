﻿using System;
using System.Collections.Generic;

namespace QLearningEX
{
	class Program
	{
		static string[] TriggerTrue = new string[]{
			"---",
			"| |",
			"| |",
			"MMM",
			"WWW",
			"   ",
			"   ",
			"   "
		};
		static string[] TriggerFalse = new string[]{
			"   ",
			"   ",
			"   ",
			"MMM",
			"WWW",
			"| |",
			"| |",
			"---"
		};

		static string[] statesString = new string[]
			{// 0     1     2     3     4     5     6     7
				"000","100","010","001","110","101","011","111"
			};

		static bool[] Triggers = new bool[] { false, false, false };
		static double GAMMA = 0.8;
        static double ALPHA = 0.1;
		static string agentState;

		static Dictionary<string, double[]> Q = new Dictionary<string, double[]>();
		static Dictionary<string, double[]> R = new Dictionary<string, double[]>();

		static void Main(string[] args)
		{
			SetupQ();
			WriteTriggers();
			WaitForInput();

			Learn();
			PrintSequences();

			WaitForInput();
		}
		static void SetupQ()
		{


			for (int state = 0; state < statesString.Length; state++)
			{
				Q[statesString[state]] = new double[3];
				R[statesString[state]] = new double[3];
				for (int action = 0; action < 3; action++)
				{

					Q[statesString[state]][action] = 0;
					if ((state == 4 && action == 2)
						|| (state == 5 && action == 1)
						|| (state == 6 && action == 0))
					{
						R[statesString[state]][action] = 100;
					}
					else
					{
						R[statesString[state]][action] = 0;
					}

				}
			}
		}

		static void Learn()
		{
			WriteRMatrix();
			WriteQMatrix();
			Random rand = new Random();

			int nextAction = 0;
			string nextState = "";
			int tr = 0;
			double hV = 0;

			double v, r;

			while (tr < 500)
			{
				agentState = statesString[rand.Next(0, 7)];
				SetTriggersToString(agentState);

				while (true)
				{
					nextAction = rand.Next(0, 3);
					nextState = ChangeTrigger(nextAction);
					Console.WriteLine(agentState + "\t" + nextAction + "\nNextState: " + nextState);

					hV = FindHighestVal(Q[nextState]);
					r = R[agentState][nextAction];
                    double newQ = r + GAMMA * hV;
                    double oldQ = Q[agentState][nextAction];
                    Q[agentState][nextAction] = oldQ + ALPHA * (newQ - oldQ);

					WriteQMatrix();
					agentState = TriggersToString();
                    if (agentState == "111")
                        break;
				}
				Console.WriteLine();
				Console.WriteLine("-----------------------End Of Test-----------------------");
				Console.WriteLine();
				tr++;
			}
			WaitForInput();

		}

		static void PrintSequences()
		{
			int nextAction;
			for (int initial = 0; initial < 7; initial++)
			{
				agentState = statesString[initial];
				Console.WriteLine("-----------------------------------------------------");
				Console.WriteLine("-----------------------------------------------------");
				Console.Write("\n" + initial + ": " + agentState + "\n");


				SetTriggersToString(agentState);
				while (true)
				{
					Console.Write("\n" + agentState);
					Console.Write(" - ");
					nextAction = FindHighestIndex(Q[agentState]);
					for (int a = 0; a < Q[agentState].Length; a++)
						Console.Write(Q[agentState][a] + "  ");

					Console.Write(" :  " + nextAction);
					Console.Write("\n");

					agentState = ChangeTrigger(nextAction);
                    if (agentState == "111")
                        break;
                    
				}
				Console.Write("\n" + agentState + "\n");
			}
		}
		static int FindHighestIndex(double[] vals)
		{
			int index = 0;
			double highest = 0;

			for (int a = 0; a < vals.Length; a++)
			{

				if (vals[a] > highest)
				{
					highest = vals[a];
					index = a;
				}
			}

			return index;
		}
		static double FindHighestVal(double[] vals)
		{
			double hVal = -1;

			for (int a = 0; a < vals.Length; a++)
			{
				if (vals[a] > hVal)
				{
					hVal = vals[a];
				}
			}

			return hVal;
		}

		static string ChangeTrigger(int trigger)
		{
			Triggers[trigger] = !Triggers[trigger];

			return TriggersToString();
		}
		static void SetTriggersToString(string input)
		{
			for (int a = 0; a < Triggers.Length; a++)
			{
				Triggers[a] = input[a] == '0' ? false : true;

			}
		}

		static void WriteQMatrix()
		{
			Console.WriteLine();
			Console.WriteLine("Q");
			Console.WriteLine();
			for (int state = 0; state < 8; state++)
			{
				Console.Write(statesString[state] + ":  ");
				for (int action = 0; action < 3; action++)
				{
					int value = (int)Q[statesString[state]][action] == 100 ? 99 : (int)Q[statesString[state]][action];
					Console.Write(value + "     \t");
				}
				Console.Write("\n");
			}
		}
		static void WriteRMatrix()
		{
			Console.WriteLine();
			Console.WriteLine("R");
			Console.WriteLine();
			for (int state = 0; state < 8; state++)
			{
				for (int action = 0; action < 3; action++)
				{
					Console.Write(R[statesString[state]][action] + "\t");
				}
				Console.Write("\n");
			}
		}

		static void WaitForInput()
		{
			Console.Read();
			Console.Read();

		}
		static string TriggersToString()
		{
			string s = "";
			for (int a = 0; a < Triggers.Length; a++)
			{
				s += Triggers[a] == true ? 1 : 0;
			}
			return s;
		}

		public static void WriteTriggers()
		{


			for (int row = 0; row < 8; row++)
			{
				if (row == 3)
				{
					Console.Write("___");
				}
				else
				{
					Console.Write("   ");
				}
				for (int a = 0; a < Triggers.Length; a++)
				{
					if (Triggers[a] == true)
					{
						Console.Write(TriggerTrue[row]);
					}
					else
					{
						Console.Write(TriggerFalse[row]);
					}
					if (row == 3)
					{
						Console.Write("___");
					}
					else
					{
						Console.Write("   ");
					}
				}
				Console.Write("\n");
			}

		}
	}
}
